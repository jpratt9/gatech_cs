# pq-planes
Calculate the range of planes based on gas mileage, etc.

Topics:
- inheritance
- polymorphism
- object oriented design

Instructions are in `index.md`
