#include "uLCD_4DGL.h"
#include "bullet.h"
#include "game_synchronizer.h"
#include "globals.h"
#include "math.h"

extern Game_Synchronizer sync;
extern Serial pc;

// Initialize the bullet. Don't have to do much here.
// Keep a pointer to this bullet's tank.
// Set the speed, and default the bullet to not in_flight.
Bullet::Bullet(Tank* t) {
    tank = t;
    speed = 25;
    in_flight = false;
    acc = -10;
}

// If in_flight, do nothing. Otherwise,
// set the in_flight flag, and initialize values needed for
// the trajectory calculations. (x0, y0), (vx0, vy0), time
// Hint: tank->barrel_end(...) is useful here.
void Bullet::shoot() {
    if(!in_flight){
        in_flight = true;
        tank->barrel_end(&x0, &y0);
        sync.pixel(x,y, 0xEEC900);
        vx0 = speed * cos(tank->barrel_theta);
        vy0 = speed * sin(tank->barrel_theta);
        time = 0;
    }
}


// If the bullet is in flight, calculate its new position
// after a time delta dt.
void Bullet::update_position(float dt) {
    if(in_flight) {
        y = floor(y0 + vy0 * time + .5 * acc * time * time);
        x = floor(x0 + vx0 * time);
        pc.printf("(barrelx,barrely) = (%d, %d) | (x0, y0) = (%d, %d) | (x, y) = (%d, %d)\n", tank->barrel_x(), tank->barrel_y(), x0, y0, x, y);
        time += dt;
    }
    
}

int Bullet::time_step(float dt) {
    // If the bullet hasn't hit anything, 
    // redraw the bullet at its new location. 
    // If it has hit something (obstacle, tank, edge of the screen), 
    // set the in_flight flag back to false, explode the nearby area,
    // and return one of the following codes.
    //
    // return codes:
    //      BULLET_NO_COLLISION: no collision
    //      BULLET_OFF_SCREEN:   off the side of the screen
    //      Otherwise, return the color you've hit in 16bpp format.
    if(in_flight) {
        int xprev = x;
        int yprev = y;
        update_position(dt);
        sync.pixel(x, y, tank->tank_color);
        int pixel = sync.read_pixel(x,y);
        if((xprev == x && yprev == y)) {// || sync.pixel_eq(pixel,0xFF1493)) {
            sync.pixel(x, y, tank->tank_color);
            return BULLET_NO_COLLISION;
        }
        if(x < 0 || x > 127 || y < 0 || y > 127){
            sync.pixel(xprev, yprev, SKY_COLOR);
            in_flight = false;
            return BULLET_OFF_SCREEN;   
        }
        
        if (sync.pixel_eq(pixel, GND_COLOR)) {
            pc.printf("Bounce!");
            //return BULLET_NO_COLLISION;    
        }
        
        if(!sync.pixel_eq(pixel, SKY_COLOR)){
            for (int i = 0; i < 20; i++) {
                //sync.filled_circle(x, y, 4, EXPL_COLOR);
                sync.filled_circle(x, y, 4, EXPL_COLOR);
                //sync.filled_circle(x, y, 4, SKY_COLOR);
                sync.filled_circle(x, y, 4, SKY_COLOR);
            }
            sync.pixel(xprev, yprev, SKY_COLOR);
            in_flight = false;
            return pixel; 
        }
        sync.pixel(xprev, yprev, SKY_COLOR);
        sync.pixel(x, y, TANK_RED);
    }
    return BULLET_NO_COLLISION;
}