#ifndef GLOBAL_H__
#define GLOBAL_H__

#define SKY_COLOR     0x57CFCF
#define GND_COLOR     0x024717
#define EXPL_COLOR    0xFF4500
#define TANK_RED      0xE33B5F
#define TANK_BLUE     0x6661B8
#define POINTER_COLOR 0xCF5757
#define LIFE_COLOR    0xEF2A2A
#define WALL_COLOR    0x6E5E66
#define MTN_COLOR     0x8A6428

#define U_BUTTON 0
#define R_BUTTON 1
#define D_BUTTON 2
#define L_BUTTON 3

#define TURN_P1 0
#define TURN_P2 1

#define LIVES 3

#define ACC_THRESHOLD 0.25

#define PI  3.1415926535797



#endif //GLOBAL_H__