// Student Side.

#include "mbed.h"

#include "SDFileSystem.h"
#include "wave_player.h"
#include "game_synchronizer.h"
#include "tank.h"
#include "bullet.h"
#include "globals.h"
#include "playSound.h"

DigitalOut led1(LED1);
DigitalOut led2(LED2);
DigitalOut led3(LED3);
DigitalOut led4(LED4);
PwmOut led_red(p25); 
PwmOut led_blue(p26); 

DigitalIn pb_u(p21);                        // Up Button
DigitalIn pb_r(p22);                        // Right Button
DigitalIn pb_d(p23);                        // Down Button
DigitalIn pb_l(p24);                        // Left Button

Serial pc(USBTX, USBRX);                    // Serial connection to PC. Useful for debugging!
MMA8452 acc(p28, p27, 100000);              // Accelerometer (SDA, SCL, Baudrate)
uLCD_4DGL uLCD(p9,p10,p11);                 // LCD (tx, rx, reset)
SDFileSystem sd(p5, p6, p7, p8, "sd");      // SD  (mosi, miso, sck, cs)
AnalogOut DACout(p18);                      // speaker
wave_player player(&DACout);                // wav player
Game_Synchronizer sync(PLAYER1);            // Game_Synchronizer (PLAYER)
Timer frame_timer;                          // Timer

// Global variables go here.
int winner = -1;
int whose_turn = PLAYER1;                   // turn
int map;                                    // map number
int mode;                                   // game mode
int shots1 = 0;
int shots2 = 0;                             // total shots fired by p1/p2
int shieldsused1 = 0;
int shieldsused2 = 0;                       // total shields used by p1/p2
int wins1 = 0;
int wins2 = 0;                              // total wins by p1/p2
int SIZE = sizeof("==================");
float dt;                                   // best not to keep declaring this variable so we just declare it here

// Ask the user whether to run the game in Single- or Multi-Player mode.
// Note that this function uses uLCD instead of sync because it is only
// writing to the local (Player1) lcd. Sync hasn't been initialized yet,
// so you can't use it anyway. For the same reason, you must access
// the buttons directly e.g. if( !pb_r ) { do something; }.

// return MULTI_PLAYER if the user selects multi-player.
// return SINGLE_PLAYER if the user selects single-player.
int game_menu() {

    uLCD.baudrate(BAUD_3000000);
    //uLCD.cls();
    uLCD.background_color(SKY_COLOR);
    uLCD.cls();
    //uLCD.filled_rectangle(0, 0, 
    // the locate command tells the screen where to place the text.
    uLCD.locate(0,0);
    uLCD.puts("==================");
    uLCD.locate(0,1);
    uLCD.puts("||     Tank     ||");
    uLCD.locate(0,2);
    uLCD.puts("||     Duel     ||");
    uLCD.locate(0,3);
    uLCD.puts("==================");
    
    uLCD.locate(0, 4);
    uLCD.puts("> Press up for");
    uLCD.locate(2, 5);
    uLCD.puts("Map 1 & 1P.");
    uLCD.locate(0 ,6);
    uLCD.puts("> Press right for");
    uLCD.locate(2, 7);
    uLCD.puts("Map 2 & 1P.");
    uLCD.locate(0, 8);
    uLCD.puts("> Press down for");
    uLCD.locate(2, 9);
    uLCD.puts("Map 1 & 2P.");
    uLCD.locate(0, 10); 
    uLCD.puts("> Press left for");
    uLCD.locate(2, 11);
    uLCD.puts("Map 2 & 2P.");
    uLCD.locate(0, 12);
    uLCD.puts("==================");
    uLCD.locate(0, 13); 
    uLCD.puts("Game History:");
    uLCD.locate(0, 14); 
    uLCD.printf("P1 Wins: %d", wins1); 
    uLCD.locate(0, 15); 
    uLCD.printf("P2 Wins: %d", wins2); 
    while (true) {
        if (!pb_u) {
            map = 1;
            return SINGLE_PLAYER;
        } else if (!pb_r) {
            map = 2; 
            return SINGLE_PLAYER;
        } else if (!pb_d) {
            map = 1;
            return MULTI_PLAYER;
        } else if (!pb_l) {
            map = 2;
            return MULTI_PLAYER;
        }
    }
}

// Initialize the world map. I've provided a basic map here,
// but as part of the assignment you must create more
// interesting map(s).
// Note that calls to sync.function() will run function()
// on both players' LCDs (assuming you are in multiplayer mode).
// In single player mode, only your lcd will be modified. (Makes sense, right?)
void map_init() {
    // Fill the entire screen with sky blue.
    sync.background_color(SKY_COLOR);
    
    // Call the clear screen function to force the LCD to redraw the screen
    // with the new background color.
    sync.cls();
    if (map == 1) {
        sync.filled_rectangle(0,0,128,20, WALL_COLOR);

        // Draw some obstacles. They don't have to be black,
        // but they shouldn't be the same color as the sky or your tanks.
        // Get creative here. You could use brown and grey to draw a mountain
        // or something cool like that.
        
        // draws some mountains in the middle
        for (int i = 21; i <= 60; i+=3) {
            sync.triangle(59, 20, 69, 20, 64, i, MTN_COLOR);
        }
        
        for (int i = 21; i<= 70; i+=3) {
            sync.triangle(49, 20, 59, 20, 54, i, MTN_COLOR);
        }
        
        for (int i = 21; i<= 90; i+=3) {
            sync.triangle(69, 20, 79, 20, 74, i, MTN_COLOR);
        }
    } else {
        
        sync.filled_rectangle(0,0,128,20, GND_COLOR);
        
        sync.filled_rectangle(59, 20, 69, 60, BLACK);
        
        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 3; j++) {
                if ((i + j) % 2 != 0) {
                    sync.filled_circle(7 + i * 15, 90 - j * 15, 5, WALL_COLOR);
                }
            }
        }
    }
    // Before you write text on the screens, tell the LCD where to put it.
    //sync.filled_rectangle(95, 0, 128, 48, 0x008B45); 
    sync.filled_circle(20, 117, 2, LIFE_COLOR); 
    sync.filled_circle(30, 117, 2, LIFE_COLOR);
    sync.filled_circle(40, 117, 2, LIFE_COLOR);
    sync.filled_circle(90, 117, 2, LIFE_COLOR);
    sync.filled_circle(100, 117, 2, LIFE_COLOR);
    sync.filled_circle(110, 117, 2, LIFE_COLOR);
    sync.locate(0,15);

    // Set the text background color to match the sky. Just for looks.
    sync.textbackground_color(SKY_COLOR);

    // Display the game title.
    char title[] = "     Tank  Duel";
    sync.puts(title, sizeof(title));

    // Flush the draw buffer and execute all the accumulated draw commands.
    sync.update();
    playSound("/sd/wavfiles/START.wav");
}

// Initialize the game hardware.
// Call game_menu to find out which mode to play the game in (Single- or Multi-Player)
// Initialize the game synchronizer.
void game_init() {

    led1 = 0; led2 = 0; led3 = 0; led4 = 0;
    whose_turn = PLAYER1; 
    pb_u.mode(PullUp);
    pb_r.mode(PullUp);
    pb_d.mode(PullUp);
    pb_l.mode(PullUp);
    
    mode = game_menu();
    sync.init(&uLCD, &acc, &pb_u, &pb_r, &pb_d, &pb_l, mode); // Connect to the other player.
    map_init();
}

int main();
int stats_screen();

// Display some kind of game over screen which lets us know who won.
// Play a cool sound!
int game_over() {
    playSound("/sd/wavfiles/FINISH.wav");
    uLCD.cls();
    sync.cls();
    uLCD.background_color(SKY_COLOR);
    sync.background_color(SKY_COLOR);
    uLCD.cls();
    sync.cls();
    
    uLCD.locate(0,0);
    uLCD.puts("==================");
    uLCD.locate(0,1);
    uLCD.puts("||     Game     ||");
    uLCD.locate(0,2);
    uLCD.puts("||     Over     ||");
    uLCD.locate(0,3);
    uLCD.puts("==================");
    
    uLCD.locate(0, 5);
    
    if (winner == PLAYER1) {
        wins1++;
        uLCD.puts("Player One Wins");
    } else {
        wins2++;
        uLCD.puts("Player Two Wins");
    }
    
    uLCD.locate(0, 7);
    uLCD.puts("> Press down to");
    uLCD.locate(2, 8);
    uLCD.puts("play again!");
    uLCD.locate(0, 10);
    uLCD.puts("> Or press up to");
    uLCD.locate(2, 11);
    uLCD.puts("show more stats");
    
    if (mode == MULTI_PLAYER || winner == PLAYER1) {
        playSound("/sd/wavfiles/WIN.wav");
    } else if (winner == PLAYER2) {
        playSound("/sd/wavfiles/LOSE.wav");    
    }
    
    while (true) {
        if (!pb_d) {
            return D_BUTTON;
        } else if (!pb_u) {
            return U_BUTTON;
        }
    }
}

int stats_screen() {
    uLCD.cls();
    uLCD.background_color(SKY_COLOR);
    uLCD.locate(0,0);
    uLCD.puts("==================");
    uLCD.locate(0,1);
    uLCD.puts("||     Stats    ||");
    uLCD.locate(0,2);
    uLCD.puts("==================");
    
    uLCD.locate(0, 4);
    uLCD.puts("> Press down to");
    uLCD.locate(2, 5);
    uLCD.puts("play again!");
    uLCD.locate(0, 6);
    uLCD.puts("~~~~~~~~~~~~~~~~~~");
    
    uLCD.locate(0, 7);
    uLCD.printf("Shots by 1: %d", shots1);
    uLCD.locate(0, 8);
    uLCD.printf("Shots by 2: %d", shots2);
    
    uLCD.locate(0, 9);
    uLCD.printf("Shields by 1: %d", shieldsused1);
    uLCD.locate(0, 10);
    uLCD.printf("Shields by 2: %d", shieldsused1);
    
    uLCD.locate(0, 11);
    uLCD.printf("P1 deaths: %d", wins2);
    uLCD.locate(0, 12);
    uLCD.printf("P2 deaths: %d", wins1);
    
    while (true) {
        if (!pb_d) {
            break;
        }
    }
    return 0;
}

void update_life(int old, int now, int x) {
    if (now < old) {
        sync.filled_circle(x, 117, 2, SKY_COLOR);
        sync.circle(x, 117, 2, LIFE_COLOR);
    }
}

int run_game() {
    int* p1_buttons;
    int* p2_buttons;
    int  life1 = LIVES; 
    int  life2 = LIVES;
    int  shieldframes1 = 0; 
    int  shieldframes2 = 0;
    bool shielded1 = false;
    bool shielded2 = false;
    bool usedshield1 = false;
    bool usedshield2 = false;
    float ax1, ay1, az1;
    float ax2, ay2, az2;
    bool p1redrawn = false;
    bool p2redrawn = false;
    int intersection_code;

    // Create your tanks.
    Tank t1(4, 21, 12, 8, TANK_RED);            // (min_x, min_y, width, height, color)
    Tank t2(111, 21, 12, 8, TANK_BLUE);         // (min_x, min_y, width, height, color)

    // For each tank, create a bullet.
    Bullet b1(&t1);
    Bullet b2(&t2); 

    frame_timer.start();
    
    // Your code starts here...
    while(true) {
        // Get a pointer to the buttons for both sides.
        // From now on, you can access the buttons for player x using
        //
        // px_buttons[U_BUTTON]
        // px_buttons[R_BUTTON]
        // px_buttons[D_BUTTON]
        // px_buttons[L_BUTTON]

        p1_buttons = sync.get_p1_buttons();
        p2_buttons = sync.get_p2_buttons();

        led1 = p1_buttons[0] ^ p2_buttons[0];
        led2 = p1_buttons[1] ^ p2_buttons[1];
        led3 = p1_buttons[2] ^ p2_buttons[2];
        led4 = p1_buttons[3] ^ p2_buttons[3];

        // Get the accelerometer values.
        sync.get_p1_accel_data(&ax1, &ay1, &az1);
        sync.get_p2_accel_data(&ax2, &ay2, &az2);

        if (whose_turn == PLAYER1) {
            p2redrawn = false;
            
            // will draw pointer in green if player is shielded
            if (!shielded1) {
                sync.triangle(4,126,4,120,12,123, POINTER_COLOR);
            } else {
                sync.triangle(4,126,4,120,12,123, GND_COLOR);
            }
            sync.triangle(123,126,123,119,116,123, SKY_COLOR);
            
            //fixes blown up tank (the other player's)
            if (!p1redrawn) {
                t1.draw();
                p1redrawn = true;
            }
                        
            // TANK MOVEMENT
            // Move the tank to the right if the accelerometer is tipped far enough to the right.
            if(ax1 < -1 * ACC_THRESHOLD) { 
                 t1.reposition(+1, 0, 0);
            // Move tank left if accelerometer is tipped far enough left.
            } else if(ax1 > ACC_THRESHOLD) {
                t1.reposition(-1,0,0);
            }
            
            // BARREL POSITIONING
            // Move tank barrel up 5 degrees (PI/72 rads) if accelerometer is tipped far enough "upward."
            if(ay1 < -1 * ACC_THRESHOLD) { 
                t1.reposition(0, 0, PI / 24);
            // Move tank barrel down 5 degrees (PI/72 rads) if accelerometer is tipped far enough "downward."
            } else if(ay1 > ACC_THRESHOLD) {
                t1.reposition(0, 0, PI / -24);
            }
            
             // SHOOTING
             // fire bullet and increment p1's shot counter if D is pressed and b1 is not in flight
             // play a firing sound before firing!
            if(p1_buttons[D_BUTTON] && !b1.in_flight) {
                playSound("/sd/wavfiles/FIRE.wav");
                b1.shoot();
                shots1++;
            }
            
            // shielding if desired! - can only be done once per game at 1 life
            // lasts 1000 frames (counter only advances during your turn)
            if (!shielded1 && p1_buttons[U_BUTTON] && life1 == 1 && !usedshield1) {
                usedshield1 = true;
                shielded1 = true;
                shieldsused1++;
            }
            
            //advance shield frame counter if shielded,
            // and remove shielding once it reaches 1000
            if (shielded1) {
                shieldframes1++;
                if (shieldframes1 == 1000) {
                    shielded1 = false;
                }    
            }
            
            dt = frame_timer.read();
            intersection_code = b1.time_step(dt);
            
            // it's p2's turn if bullet goes off screen or hits something
            if(intersection_code != BULLET_NO_COLLISION || intersection_code == BULLET_OFF_SCREEN) { 
                whose_turn = PLAYER2;
            }
            
            // If you shot yourself, you lose a life.
            if(sync.pixel_eq(intersection_code, t1.tank_color) && !shielded1) { 
                life1--;
                playSound("/sd/wavfiles/DAMAGE.wav");
            }
            
            // If you shot the other guy, he loses a life.
            if(sync.pixel_eq(intersection_code, t2.tank_color)) { 
                life2--;
                playSound("/sd/wavfiles/DAMAGE.wav");
            }
            sync.update();
        } else if(whose_turn == PLAYER2 && mode == SINGLE_PLAYER) {
            
            // I gave you a lot of the logic for Player1. It's up to you to figure out Player2!
            // If you are in SINGLE_PLAYER mode, you should use the p1 inputs to control p2.
            // In MULTI_PLAYER mode, you should use the p2 inputs to control p2.
            //
            // Hint: 
            //         sync.play_mode will tell you if you are in MULTI_PLAYER or SINGLE_PLAYER mode.
            //
            
            if (!shielded2) {
                sync.triangle(123,126,123,119,116,123, POINTER_COLOR);
            } else {
                sync.triangle(123,126,123,119,116,123, GND_COLOR);
            }
            sync.triangle(4,126,4,120,12,123, SKY_COLOR);
            
            p1redrawn = false;
            
            if (!p2redrawn) {
                t2.draw();
                p2redrawn = true;
            }
                        
            // TANK MOVEMENT
            // Move the tank to the right if the accelerometer is tipped far enough to the right.
            if(ax1 < -1 * ACC_THRESHOLD) { 
                 t2.reposition(+1, 0, 0);
            // Move tank left if accelerometer is tipped far enough left.
            } else if(ax1 > ACC_THRESHOLD) {
                t2.reposition(-1,0,0);
            }
            
            // BARREL POSITIONING
            // Move tank barrel up 5 degrees (PI/72 rads) if accelerometer is tipped far enough "upward."
            if(ay1 < -1 * ACC_THRESHOLD) { 
                t2.reposition(0, 0, PI / 24);
            // Move tank barrel down 5 degrees (PI/72 rads) if accelerometer is tipped far enough "downward."
            } else if(ay1 > ACC_THRESHOLD) {
                t2.reposition(0, 0, PI / -24);
            }
            
             // SHOOTING
            if(p1_buttons[D_BUTTON] && !b2.in_flight) {
                playSound("/sd/wavfiles/FIRE.wav");
                b2.shoot();
                shots2++;
            }
            
            // shielding if desired! - can only be done once per game at 1 life
            // lasts 10000 frames (counter only advances during your turn)
            if (!shielded2 && p1_buttons[U_BUTTON] && life2 == 1 && !usedshield2) {
                usedshield2 = true;
                shielded2 = true;
                shieldsused2++;
            }
            
            if (shielded2) {
                shieldframes2++;
                if (shieldframes2 == 1000) {
                    shielded2 = false;
                }    
            }
            
            dt = frame_timer.read();
            intersection_code = b2.time_step(dt); 
            
            if(intersection_code != BULLET_NO_COLLISION || intersection_code == BULLET_OFF_SCREEN) { 
                whose_turn = PLAYER1;
                // turn indicator - p2
            }
            
            // If you shot yourself, you lose a life.
            if(sync.pixel_eq(intersection_code, t2.tank_color) && !shielded2) { 
                life2--;
                playSound("/sd/wavfiles/DAMAGE.wav");
               
            }
            
            // If you shot the other guy, he loses a life.
            if(sync.pixel_eq(intersection_code, t1.tank_color)) { 
                life1--;
                playSound("/sd/wavfiles/DAMAGE.wav");
            }
            sync.update();
        //MULTIPLAYER - P2
        } else if (mode == MULTI_PLAYER && whose_turn == PLAYER2) {
            if (!shielded2) {
                sync.triangle(123,126,123,119,116,123, POINTER_COLOR);
            } else {
                sync.triangle(123,126,123,119,116,123, GND_COLOR);
            }
            sync.triangle(4,126,4,120,12,123, SKY_COLOR);
            
            p1redrawn = false;
            
            if (!p2redrawn) {
                t2.draw();
                p2redrawn = true;
            }
                        
            // TANK MOVEMENT
            // Use P2's accelerometer
            // Move the tank to the right if the accelerometer is tipped far enough to the right.
            if(ax2 < -1 * ACC_THRESHOLD) { 
                 t2.reposition(+1, 0, 0);
            // Move tank left if accelerometer is tipped far enough left.
            } else if(ax2 > ACC_THRESHOLD) {
                t2.reposition(-1,0,0);
            }
            
            // BARREL POSITIONING
            // Move tank barrel up 5 degrees (PI/72 rads) if accelerometer is tipped far enough "upward."
            if(ay2 < -1 * ACC_THRESHOLD) { 
                t2.reposition(0, 0, PI / 24);
            // Move tank barrel down 5 degrees (PI/72 rads) if accelerometer is tipped far enough "downward."
            } else if(ay2 > ACC_THRESHOLD) {
                t2.reposition(0, 0, PI / -24);
            }
            
             // SHOOTING
            if(p2_buttons[D_BUTTON] && !b2.in_flight) {
                playSound("/sd/wavfiles/FIRE.wav");
                b2.shoot();
                shots2++;
            }
            
            // shielding if desired! - can only be done once per game at 1 life
            // lasts 10000 frames (counter only advances during your turn)
            if (!shielded2 && p2_buttons[U_BUTTON] && life2 == 1 && !usedshield2) {
                usedshield2 = true;
                shielded2 = true;
                shieldsused2++;
            }
            
            if (shielded2) {
                shieldframes2++;
                if (shieldframes2 == 1000) {
                    shielded2 = false;
                }    
            }
            
            dt = frame_timer.read();
            intersection_code = b2.time_step(dt); 
            
            if(intersection_code != BULLET_NO_COLLISION || intersection_code == BULLET_OFF_SCREEN) { 
                whose_turn = PLAYER1;
                // turn indicator - p2
            }
            
            // If you shot yourself, you lose a life.
            if(sync.pixel_eq(intersection_code, t2.tank_color) && !shielded2) { 
                life2--;
                playSound("/sd/wavfiles/DAMAGE.wav");
               
            }
            
            // If you shot the other guy, he loses a life.
            if(sync.pixel_eq(intersection_code, t1.tank_color)) { 
                life1--;
                playSound("/sd/wavfiles/DAMAGE.wav");
            }
            sync.update();
        }
        frame_timer.reset();
        
        // update life symbols
        update_life(1, life1, 20);
        update_life(2, life1, 30);
        update_life(3, life1, 40);
        
        update_life(3, life2, 90);
        update_life(2, life2, 100);
        update_life(1, life2, 110);
        
        if (sync.pixel_eq(intersection_code, TANK_RED)) {
            t1.draw();
        }
        
        if (sync.pixel_eq(intersection_code, TANK_BLUE)) {
            t2.draw();
        }
        
        if (sync.pixel_eq(intersection_code, 0x000000)) {
            t1.draw();
            t2.draw();
        }
        
        if (life1 == 0) {
            winner = PLAYER2;
            break;
        } else if (life2 == 0) {
            winner = PLAYER1;
            break;
        }
    }
    return 0;
    sync.update();
}

int main() {
    start:
    game_init();
    run_game();
    int newmode = game_over();
    if (newmode == D_BUTTON) {
        goto start;
    } else {
        stats_screen();
        goto start;
    }
}